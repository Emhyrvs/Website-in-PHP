import javax.swing.*;

import java.awt.*;
import java.awt.event.*;

public class Okno extends JFrame {private JLabel lbImie, lbNazwisko,lbMiejscowosc;
    private static JTextField tfImie, tfNazwisko,tfMiejscowosc;
    private JButton bOK;
    private JButton bClose;
    private JFrame frame;
    Okno()
    {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(800,400);
        setLayout(new GridLayout(8,2));
        add(lbImie=new JLabel("Imie"));
        add(tfImie=new JTextField(10));
        add(lbNazwisko=new JLabel("Nazwisko"));
        add(tfNazwisko=new JTextField(10));
        String [] c = new String [] {"Warszawa", "Siedlce", "Kraków "};
        JComboBox<String> x =new JComboBox<String>(c);


        add(lbMiejscowosc=new JLabel("Miejscowosc"));
        add(x);

        JRadioButton option1 = new JRadioButton("student");
        JRadioButton option2 = new JRadioButton("pracownik");
        ButtonGroup group = new ButtonGroup();

        group.add(option1);
        group.add(option2);
        add(option1);
        add(option2);


        add(bOK=new JButton("OK"));
        add(bClose=new JButton("Zamknij"));




        bOK.addActionListener(new ActionListener()
                              {
                                  public void actionPerformed(ActionEvent e)
                                  {

                                      try{
                                          if(option1.isSelected())
                                          {

                                              JFrame p = new OknoS();
                                          }
                                          else
                                          {

                                              JFrame h = new OknoP();
                                          }

                                      }
                                      catch(Exception ex)
                                      {
                                          SwingUtilities.updateComponentTreeUI(getContentPane());
                                      }

                                  }
                              }
        );
        bClose.addActionListener(new ActionListener()
                                 {
                                     public void actionPerformed(ActionEvent e)
                                     {
                                         System.exit(0);
                                     }
                                 }
        );


        setVisible(true);
    }
    public static void main (String args[]) {
        JFrame f; f = new Okno();

    }

}
