import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;



public class OknoP extends Okno {
    private JLabel firma, stanowisko,pobory_brutto,kursy;
    private static JTextField  lfirma, lstanowisko,lpobory_lbrutto,lkursy;
    private JButton bOK;
    private JButton bClose;

    OknoP() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(600, 400);
        setLayout(new GridLayout(10, 4));
        add(firma = new JLabel("Firma"));
        add(lfirma = new JTextField(10));
        add(stanowisko = new JLabel("stanowski"));
        add(lstanowisko= new JTextField(10));
        add(pobory_brutto = new JLabel("Pobory"));
        add(lpobory_lbrutto = new JTextField(10));
        add(kursy= new JLabel("Kursy"));
        add(lkursy= new JTextField(10));
        add(bOK=new JButton("OK"));
        add(bClose=new JButton("Zamknij"));

        bClose.addActionListener(new ActionListener()
                                 {
                                     public void actionPerformed(ActionEvent e)
                                     {
                                         System.exit(0);
                                     }
                                 }
        );


        setVisible(true);
    }





}
