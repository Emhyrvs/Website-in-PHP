


import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

    public class OknoS extends Okno {
        private JLabel lbUczelnia, lbKierunek;
        private static JTextField tfUczelnia, tfKierunek;
        private JButton bOK;
        private JButton bClose;

        OknoS() {
            setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            setSize(800, 400);
            setLayout(new GridLayout(8, 2));
            add(lbUczelnia = new JLabel("Uczelnia"));
            add(tfUczelnia = new JTextField(10));
            add(lbKierunek = new JLabel("Kierunek"));
            add(tfKierunek = new JTextField(10));
            add(bOK=new JButton("OK"));
            add(bClose=new JButton("Zamknij"));

  bClose.addActionListener(new ActionListener()
        {
            public void actionPerformed(ActionEvent e)
            {
                System.exit(0);
            }
        }
        );


        setVisible(true);
    }




    }
