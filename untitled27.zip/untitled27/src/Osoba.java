public abstract class Osoba {
    private String imie;
    private String nazwisko;
    private String miejscowosc;
    public Osoba()
    {
        this.imie="xx";
        this.nazwisko="yy";
        this.miejscowosc="Siedlce";
    }
    public Osoba(String imie,String nazwisko,String miejscowosc)
    {
        this.imie=imie;
        this.nazwisko=nazwisko;
        this.miejscowosc=miejscowosc;
    }

    public String getImie() {
        return imie;
    }

    public String getNazwisko() {
        return nazwisko;
    }

    public String getMiejscowosc() {
        return miejscowosc;
    }

    public void setImie(String imie) {
        this.imie = imie;
    }

    public void setMiejscowosc(String miejscowosc) {
        this.miejscowosc = miejscowosc;
    }

    public void setNazwisko(String nazwisko) {
        this.nazwisko = nazwisko;
    }
    abstract String info();
    abstract double oblicz();

}
