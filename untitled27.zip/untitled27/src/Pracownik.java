public class Pracownik extends Osoba {

    private String firma;
    private String stanowisko;
    private double pobory;
    private String [] kursy ;
    public Pracownik(String imie,String nazwisko,String miejscowosc,String firma,String stanowisko,double pobory , String [] kursy)
    {
        super(imie,nazwisko,miejscowosc);
        this.firma=firma;
        this.stanowisko=stanowisko;
        this.pobory=pobory;
        this.kursy=kursy;
    }

    public String getFirma() {
        return firma;
    }

    @Override
    public String getImie() {
        return super.getImie(); //To change body of generated methods, choose Tools | Templates.
    }

    public String[] getKursy() {
        return kursy;
    }

    @Override
    public String getMiejscowosc() {
        return super.getMiejscowosc(); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public String getNazwisko() {
        return super.getNazwisko(); //To change body of generated methods, choose Tools | Templates.
    }

    public double getPobory() {
        return pobory;
    }

    public String getStanowisko() {
        return stanowisko;
    }

    public void setFirma(String firma) {
        this.firma = firma;
    }

    @Override
    public void setImie(String imie) {
        super.setImie(imie); //To change body of generated methods, choose Tools | Templates.
    }

    public void setKursy(String[] kursy) {
        this.kursy = kursy;
    }

    @Override
    public void setMiejscowosc(String miejscowosc) {
        super.setMiejscowosc(miejscowosc); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void setNazwisko(String nazwisko) {
        super.setNazwisko(nazwisko); //To change body of generated methods, choose Tools | Templates.
    }

    public void setStanowisko(String stanowisko) {
        this.stanowisko = stanowisko;
    }

    public void setPobory(double pobory) {
        this.pobory = pobory;
    }



    @Override
    public String info() {
        String toReturn="";
        String kur="";
        for(int i=0;i<5;i++)
        {
            kur+=kursy[i]+", ";
        }
        toReturn="Imie: "+getImie()+" Nazwisko: "+getNazwisko()+" Miejscowosc: "+getMiejscowosc()+
                " Firma: "+getFirma()+" Stanowisko: "+getStanowisko()+" Pobory: "+ pobory+" Kursy "+kur;
        return toReturn;
    }

    @Override
    public double oblicz() {
        return 0.81*pobory;
    }

}
