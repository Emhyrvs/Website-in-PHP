public class Student extends Osoba{
    private String uczelnia;
    private String kierunek;
    private double [] ocena;

    public Student(String imie,String nazwisko,String miejscowosc,String uczelnia,String kierunek,double [] ocena )
    {
        super(imie,nazwisko,miejscowosc);
        this.uczelnia=uczelnia;
        this.kierunek=kierunek;
        this.ocena=ocena;
    }

    @Override
    public String getImie() {
        return super.getImie(); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public String getNazwisko() {
        return super.getNazwisko(); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public String getMiejscowosc() {
        return super.getMiejscowosc(); //To change body of generated methods, choose Tools | Templates.
    }

    public String getKierunek() {
        return kierunek;
    }

    public String getUczelnia() {
        return uczelnia;
    }

    public double[] getOcena() {
        return ocena;
    }

    @Override
    public void setImie(String imie) {
        super.setImie(imie); //To change body of generated methods, choose Tools | Templates.
    }

    public void setKierunek(String kierunek) {
        this.kierunek = kierunek;
    }

    @Override
    public void setMiejscowosc(String miejscowosc) {
        super.setMiejscowosc(miejscowosc); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void setNazwisko(String nazwisko) {
        super.setNazwisko(nazwisko); //To change body of generated methods, choose Tools | Templates.
    }

    public void setOcena(double[] ocena) {
        this.ocena = ocena;
    }

    public void setUczelnia(String uczelnia) {
        this.uczelnia = uczelnia;
    }



    @Override
    public String info() {
        String toReturn="";
        String oc="";
        for(int i=0;i<5;i++)
        {
            oc+=ocena[i]+", ";
        }
        toReturn="Imie: "+getImie()+" Nazwisko: "+getNazwisko()+" Miejscowosc: "+getMiejscowosc()+
                " Uczelnia: "+getUczelnia()+" Kierunek: "+getKierunek()+" ocena: "+ oc;
        return toReturn;
    }

    @Override
    public double oblicz() {
        double sr=0;
        for(int i=0;i<5;i++)
        {
            sr+=ocena[i];
        }
        return sr/5;
    }

}
